package de.farmlagfix;

import java.util.function.Predicate;

/** Kategorien von Bloecken, die einzeln ausgeblendet werden koennen. Gematcht wird ueber den Block-Namen. */
public enum RedstonePart {
	WIRE("Redstone-Kabel", p -> p.equals("redstone_wire")),
	REPEATER("Repeater", p -> p.equals("repeater")),
	COMPARATOR("Comparator", p -> p.equals("comparator")),
	TORCH("Redstone-Fackeln", p -> p.equals("redstone_torch") || p.equals("redstone_wall_torch")),
	OBSERVER("Observer", p -> p.equals("observer")),
	PISTON("Kolben", p -> p.equals("piston") || p.equals("sticky_piston") || p.equals("piston_head")),
	HOPPER("Trichter", p -> p.equals("hopper")),
	DISPENSER("Werfer / Spender", p -> p.equals("dispenser") || p.equals("dropper")),
	INPUTS("Hebel / Knoepfe / Platten", p -> p.equals("lever") || p.endsWith("_button") || p.endsWith("pressure_plate")),
	TRIPWIRE("Stolperdraht", p -> p.equals("tripwire") || p.equals("tripwire_hook")),
	RAILS("Schienen", p -> p.equals("rail") || p.equals("powered_rail") || p.equals("detector_rail") || p.equals("activator_rail")),
	REDSTONE_MISC("Redstoneblock / Lampe / Target", p -> p.equals("redstone_block") || p.equals("redstone_lamp") || p.equals("target") || p.equals("daylight_detector")),
	SLIME("Schleim- / Honigbloecke", p -> p.equals("slime_block") || p.equals("honey_block"));

	public final String label;
	private final Predicate<String> matcher;

	RedstonePart(String label, Predicate<String> matcher) {
		this.label = label;
		this.matcher = matcher;
	}

	public boolean matches(String blockPath) {
		return matcher.test(blockPath);
	}
}
