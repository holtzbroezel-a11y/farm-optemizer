package de.farmlagfix;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public final class FarmConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	// ---- Einstellungen (werden als JSON gespeichert) ----
	public boolean showItems = true;
	/** 0 = unbegrenzt, sonst Bloecke */
	public int itemRenderDistance = 0;
	public boolean showXpOrbs = true;
	public boolean itemNameTags = false;
	public boolean nameTagShowCount = true;
	public int nameTagDistance = 16;
	/** Renderdistanz fuer alle Entities ausser Spielern. 0 = unbegrenzt */
	public int entityRenderDistance = 0;
	public boolean hideMovingPistons = false;
	/** true = Teil wird ausgeblendet */
	public Map<String, Boolean> hiddenParts = new LinkedHashMap<>();

	public static FarmConfig I = new FarmConfig();

	private static volatile Set<Block> hiddenBlocks = Collections.emptySet();

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("farmlagfix.json");
	}

	public static void load() {
		Path f = file();
		if (Files.exists(f)) {
			try (Reader r = Files.newBufferedReader(f)) {
				FarmConfig loaded = GSON.fromJson(r, FarmConfig.class);
				if (loaded != null) {
					I = loaded;
				}
			} catch (Exception e) {
				FarmLagFixClient.LOGGER.warn("Konnte Config nicht lesen, nutze Standardwerte", e);
			}
		}
		if (I.hiddenParts == null) {
			I.hiddenParts = new LinkedHashMap<>();
		}
		for (RedstonePart p : RedstonePart.values()) {
			I.hiddenParts.putIfAbsent(p.name(), false);
		}
	}

	public static void save() {
		try (Writer w = Files.newBufferedWriter(file())) {
			GSON.toJson(I, w);
		} catch (IOException e) {
			FarmLagFixClient.LOGGER.warn("Konnte Config nicht speichern", e);
		}
	}

	public boolean isPartHidden(RedstonePart part) {
		return Boolean.TRUE.equals(hiddenParts.get(part.name()));
	}

	public void setPartHidden(RedstonePart part, boolean hidden) {
		hiddenParts.put(part.name(), hidden);
	}

	/** Baut die Menge der ausgeblendeten Bloecke neu auf (Registry muss geladen sein). */
	public static void rebuildHiddenBlocks() {
		Set<Block> set = new HashSet<>();
		for (Block block : BuiltInRegistries.BLOCK) {
			var key = BuiltInRegistries.BLOCK.getKey(block);
			if (!"minecraft".equals(key.getNamespace())) {
				continue;
			}
			String path = key.getPath();
			for (RedstonePart part : RedstonePart.values()) {
				if (I.isPartHidden(part) && part.matches(path)) {
					set.add(block);
					break;
				}
			}
		}
		hiddenBlocks = set;
	}

	/** Baut die Block-Liste neu auf und laesst die Welt neu rendern. */
	public static void applyRedstoneChange() {
		rebuildHiddenBlocks();
		Minecraft mc = Minecraft.getInstance();
		if (mc.levelRenderer != null && mc.level != null) {
			mc.levelRenderer.allChanged();
		}
	}

	// ---- Hot Paths fuer die Mixins ----

	public static boolean isBlockHidden(Block block) {
		Set<Block> set = hiddenBlocks;
		return !set.isEmpty() && set.contains(block);
	}

	public static boolean shouldHideEntity(Entity entity, double camX, double camY, double camZ) {
		FarmConfig c = I;
		if (entity instanceof ItemEntity) {
			if (!c.showItems) {
				return true;
			}
			return c.itemRenderDistance > 0 && entity.distanceToSqr(camX, camY, camZ) > sq(c.itemRenderDistance);
		}
		if (entity instanceof ExperienceOrb) {
			return !c.showXpOrbs;
		}
		if (c.entityRenderDistance > 0 && !(entity instanceof Player)) {
			return entity.distanceToSqr(camX, camY, camZ) > sq(c.entityRenderDistance);
		}
		return false;
	}

	private static double sq(int v) {
		return (double) v * v;
	}
}
