package de.farmlagfix;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

public class FarmLagScreen extends Screen {
	private static final int[] DISTANCES = {0, 8, 16, 32, 64, 128};
	private static final int[] TAG_DISTANCES = {8, 16, 32, 64};

	private final Screen parent;
	private int page = 0;
	private boolean redstoneDirty = false;

	public FarmLagScreen(Screen parent) {
		super(Component.literal("FarmLagFix"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		FarmConfig c = FarmConfig.I;
		int left = this.width / 2 - 155;
		int right = this.width / 2 + 5;

		this.addRenderableWidget(new StringWidget(this.width / 2 - 150, 8, 300, 9, this.title, this.font).alignCenter());

		Button tabItems = Button.builder(Component.literal("Items & Tags"), b -> {
			this.page = 0;
			this.rebuildWidgets();
		}).bounds(left, 20, 150, 20).build();
		tabItems.active = this.page != 0;
		this.addRenderableWidget(tabItems);

		Button tabRedstone = Button.builder(Component.literal("Redstone-Teile"), b -> {
			this.page = 1;
			this.rebuildWidgets();
		}).bounds(right, 20, 150, 20).build();
		tabRedstone.active = this.page != 1;
		this.addRenderableWidget(tabRedstone);

		int startY = 48;
		String hint;

		if (this.page == 0) {
			addToggle(slotX(0, left, right), slotY(0, startY), "Items anzeigen", "AN", "AUS",
					() -> c.showItems, v -> c.showItems = v, false);
			addCycle(slotX(1, left, right), slotY(1, startY), "Item-Distanz", DISTANCES,
					() -> c.itemRenderDistance, v -> c.itemRenderDistance = v, FarmLagScreen::distText);
			addToggle(slotX(2, left, right), slotY(2, startY), "XP-Orbs anzeigen", "AN", "AUS",
					() -> c.showXpOrbs, v -> c.showXpOrbs = v, false);
			addCycle(slotX(3, left, right), slotY(3, startY), "Mob-Distanz", DISTANCES,
					() -> c.entityRenderDistance, v -> c.entityRenderDistance = v, FarmLagScreen::distText);
			addToggle(slotX(4, left, right), slotY(4, startY), "Item-Name-Tags", "AN", "AUS",
					() -> c.itemNameTags, v -> c.itemNameTags = v, false);
			addCycle(slotX(5, left, right), slotY(5, startY), "Tag-Reichweite", TAG_DISTANCES,
					() -> c.nameTagDistance, v -> c.nameTagDistance = v, v -> v + " Bl.");
			addToggle(slotX(6, left, right), slotY(6, startY), "Tag mit Anzahl", "AN", "AUS",
					() -> c.nameTagShowCount, v -> c.nameTagShowCount = v, false);
			addToggle(slotX(7, left, right), slotY(7, startY), "Kolben-Animation", "ausgeblendet", "sichtbar",
					() -> c.hideMovingPistons, v -> c.hideMovingPistons = v, false);
			hint = "Name-Tags erscheinen nur bei Items, die angezeigt werden.";
		} else {
			RedstonePart[] parts = RedstonePart.values();
			for (int i = 0; i < parts.length; i++) {
				RedstonePart part = parts[i];
				addToggle(slotX(i, left, right), slotY(i, startY), part.label, "ausgeblendet", "sichtbar",
						() -> c.isPartHidden(part), v -> c.setPartHidden(part, v), true);
			}
			hint = "Aenderungen werden beim Schliessen angewendet (Welt wird neu aufgebaut).";
		}

		this.addRenderableWidget(new StringWidget(this.width / 2 - 200, this.height - 42, 400, 9,
				Component.literal(hint), this.font).alignCenter());

		this.addRenderableWidget(Button.builder(Component.literal("Fertig"), b -> this.onClose())
				.bounds(this.width / 2 - 100, this.height - 28, 200, 20).build());
	}

	private static int slotX(int index, int left, int right) {
		return index % 2 == 0 ? left : right;
	}

	private static int slotY(int index, int startY) {
		return startY + (index / 2) * 22;
	}

	private static String distText(int v) {
		return v == 0 ? "unbegrenzt" : v + " Bl.";
	}

	private static Component text(String label, String value) {
		return Component.literal(label + ": " + value);
	}

	private void addToggle(int x, int y, String label, String onText, String offText,
						   BooleanSupplier getter, Consumer<Boolean> setter, boolean redstone) {
		Button button = Button.builder(text(label, getter.getAsBoolean() ? onText : offText), b -> {
			setter.accept(!getter.getAsBoolean());
			b.setMessage(text(label, getter.getAsBoolean() ? onText : offText));
			if (redstone) {
				this.redstoneDirty = true;
			}
		}).bounds(x, y, 150, 20).build();
		this.addRenderableWidget(button);
	}

	private void addCycle(int x, int y, String label, int[] values, IntSupplier getter,
						  IntConsumer setter, IntFunction<String> format) {
		Button button = Button.builder(text(label, format.apply(getter.getAsInt())), b -> {
			int idx = 0;
			for (int i = 0; i < values.length; i++) {
				if (values[i] == getter.getAsInt()) {
					idx = i;
					break;
				}
			}
			setter.accept(values[(idx + 1) % values.length]);
			b.setMessage(text(label, format.apply(getter.getAsInt())));
		}).bounds(x, y, 150, 20).build();
		this.addRenderableWidget(button);
	}

	@Override
	public void onClose() {
		this.minecraft.setScreen(this.parent);
	}

	@Override
	public void removed() {
		FarmConfig.save();
		if (this.redstoneDirty) {
			FarmConfig.applyRedstoneChange();
			this.redstoneDirty = false;
		}
	}
}
