package de.farmlagfix.mixin;

import de.farmlagfix.FarmConfig;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Entities (Items, XP-Orbs, weit entfernte Mobs) gar nicht erst rendern. */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
	private void farmlagfix$skipEntity(Entity entity, Frustum frustum, double camX, double camY, double camZ,
									   CallbackInfoReturnable<Boolean> cir) {
		if (FarmConfig.shouldHideEntity(entity, camX, camY, camZ)) {
			cir.setReturnValue(false);
		}
	}
}
