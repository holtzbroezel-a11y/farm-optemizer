package de.farmlagfix.mixin;

import de.farmlagfix.FarmConfig;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Item-Name-Tags ueber gedroppten Items. */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
	@Inject(method = "shouldShowName", at = @At("HEAD"), cancellable = true, require = 0)
	private void farmlagfix$showItemTag(Entity entity, double distanceToCameraSq, CallbackInfoReturnable<Boolean> cir) {
		FarmConfig c = FarmConfig.I;
		if (c.itemNameTags && entity instanceof ItemEntity) {
			double r = c.nameTagDistance;
			cir.setReturnValue(distanceToCameraSq <= r * r);
		}
	}

	@Inject(method = "getNameTag", at = @At("HEAD"), cancellable = true, require = 0)
	private void farmlagfix$itemTagText(Entity entity, CallbackInfoReturnable<Component> cir) {
		FarmConfig c = FarmConfig.I;
		if (c.itemNameTags && entity instanceof ItemEntity itemEntity) {
			ItemStack stack = itemEntity.getItem();
			MutableComponent text = stack.getHoverName().copy();
			if (c.nameTagShowCount && stack.getCount() > 1) {
				text.append(Component.literal(" x" + stack.getCount()));
			}
			cir.setReturnValue(text);
		}
	}
}
