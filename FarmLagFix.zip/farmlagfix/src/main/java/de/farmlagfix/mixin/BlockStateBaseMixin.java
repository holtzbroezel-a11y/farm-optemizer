package de.farmlagfix.mixin;

import de.farmlagfix.FarmConfig;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Ausgeblendete Redstone-Teile bekommen die Render-Form INVISIBLE.
 * Das betrifft nur das Rendern, nicht die Spiellogik.
 */
@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockStateBaseMixin {
	@Inject(method = "getRenderShape", at = @At("HEAD"), cancellable = true, require = 0)
	private void farmlagfix$hideRedstoneParts(CallbackInfoReturnable<RenderShape> cir) {
		BlockState self = (BlockState) (Object) this;
		if (FarmConfig.isBlockHidden(self.getBlock())) {
			cir.setReturnValue(RenderShape.INVISIBLE);
		}
	}
}
