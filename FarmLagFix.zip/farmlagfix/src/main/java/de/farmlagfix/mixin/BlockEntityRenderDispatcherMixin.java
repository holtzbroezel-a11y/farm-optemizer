package de.farmlagfix.mixin;

import de.farmlagfix.FarmConfig;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.piston.PistonMovingBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Animation der bewegten Kolbenbloecke weglassen (grosser Lagverursacher bei Piston-Farmen). */
@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityRenderDispatcherMixin {
	@Inject(method = "getRenderer", at = @At("HEAD"), cancellable = true, require = 0)
	private void farmlagfix$skipMovingPiston(BlockEntity blockEntity, CallbackInfoReturnable<?> cir) {
		if (FarmConfig.I.hideMovingPistons && blockEntity instanceof PistonMovingBlockEntity) {
			cir.setReturnValue(null);
		}
	}
}
