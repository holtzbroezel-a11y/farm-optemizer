package de.farmlagfix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FarmLagFixClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("farmlagfix");

	private static volatile boolean openRequested = false;

	@Override
	public void onInitializeClient() {
		FarmConfig.load();

		// Registry ist erst nach dem Start des Clients komplett
		ClientLifecycleEvents.CLIENT_STARTED.register(client -> FarmConfig.rebuildHiddenBlocks());

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
			dispatcher.register(ClientCommandManager.literal("farmlag").executes(ctx -> {
				openRequested = true;
				return 1;
			}));
			dispatcher.register(ClientCommandManager.literal("fl").executes(ctx -> {
				openRequested = true;
				return 1;
			}));
		});

		// Screen erst im naechsten Tick oeffnen, sonst schliesst der Chat es sofort wieder
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (openRequested) {
				openRequested = false;
				Minecraft mc = Minecraft.getInstance();
				mc.setScreen(new FarmLagScreen(null));
			}
		});

		LOGGER.info("FarmLagFix geladen - Menue mit /farmlag oder /fl");
	}
}
